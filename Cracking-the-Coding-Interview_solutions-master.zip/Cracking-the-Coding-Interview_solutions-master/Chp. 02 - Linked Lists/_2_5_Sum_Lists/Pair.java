package _2_5_Sum_Lists;

import common.Node;

class Pair {
    Node node;
    int carry;
    Pair(Node node, int carry) {
        this.node  = node;
        this.carry = carry;
    }
}
