package _17_11_Word_Distance;

public class Pair {
	public Integer num;
	public boolean fromListA;
	
	public Pair(Integer n, boolean bool) {
		num = n;
		fromListA = bool;
	}
}
