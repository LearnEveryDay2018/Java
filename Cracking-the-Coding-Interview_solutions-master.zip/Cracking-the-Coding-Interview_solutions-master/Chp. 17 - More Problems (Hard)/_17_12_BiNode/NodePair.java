package _17_12_BiNode;

class NodePair {
	BiNode head;
	BiNode tail;
	
	public NodePair(BiNode h, BiNode t) {
		head = h;
		tail = t;
	}
}
