package _17_12_BiNode;

public class BiNode {
	public BiNode left, right;
	public int data;
	
	public BiNode(int d) {
		left  = null;
		right = null;
		data  = d;
	}
}
