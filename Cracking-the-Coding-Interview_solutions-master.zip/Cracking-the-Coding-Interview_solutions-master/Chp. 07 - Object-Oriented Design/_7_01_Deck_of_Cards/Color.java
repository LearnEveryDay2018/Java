package _7_01_Deck_of_Cards;

public enum Color {
	RED, BLACK;
}
