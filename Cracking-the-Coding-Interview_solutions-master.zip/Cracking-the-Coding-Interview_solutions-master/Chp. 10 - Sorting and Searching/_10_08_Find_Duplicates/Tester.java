package _10_08_Find_Duplicates;

public class Tester {
	public static void main(String[] args) {
		System.out.println("*** Test 10.4: Find Duplicates");
		FindDuplicates.checkDuplicates(new int[]{3,4,4,4,1,6,1});
	}
}
