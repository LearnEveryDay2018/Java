package _16_10_Living_People;

public class Person {
	int birth;
	int death;

	Person(int birth, int death) {
		this.birth = birth;
		this.death = death;
	}
}
