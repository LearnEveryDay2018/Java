package _16_25_LRU_Cache;

class Item {
	String name;
	
	Item(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return name;
	}
}
