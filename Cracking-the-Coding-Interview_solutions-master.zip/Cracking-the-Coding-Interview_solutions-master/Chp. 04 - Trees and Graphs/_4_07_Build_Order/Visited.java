package _4_07_Build_Order;

public enum Visited {
	NEW, ACTIVE, DONE
}
